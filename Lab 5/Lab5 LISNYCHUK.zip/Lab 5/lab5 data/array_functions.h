#pragma once

void show(int* a);
void fill(int* a);
void sort(int* a);